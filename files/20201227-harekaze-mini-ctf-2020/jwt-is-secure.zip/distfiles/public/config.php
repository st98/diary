<?php
define('FLAG', 'HarekazeCTF{<redacted>}');
define('COOKIE_NAME', 'jwtsession');
define('CHALLENGE_NAME', 'JWT is secure');
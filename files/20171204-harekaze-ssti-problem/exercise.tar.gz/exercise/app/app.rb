require 'sinatra'
require 'logger'

set :public_folder, File.dirname(__FILE__) + '/static'
enable :sessions

logger = Logger.new('sinatra.log')

def is_valid(s)
  return /^[0-9A-Za-z]+$/ =~ s
end

get '/' do
  erb :index
end

post '/add' do
  unless session[:memos]
    session[:memos] = []
  end
  unless is_valid(params[:memo])
    redirect to('/')
  end
  session[:memos].push params[:memo]
  logger.info erb("memo ('#{params[:memo]}') added", :layout => false)
  redirect to('/')
end

get '/clear' do
  if params[:id]
    id = params[:id].to_i
    logger.info erb("memo ('#{session[:memos][id]}') deleted", :layout => false)
    session[:memos].slice! id
  else
    session.clear
  end
  redirect to('/')
end

get '/source' do
  File.open(__FILE__, 'r').read
end